package com.view;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.model.GameModel;
import com.model.localmap.MapSnapshot;
import com.model.localmap.Position;

public class SimpleView implements GameView {
    private GameModel model;
    private int windowWidth;
    private int windowHeight;
    private int tileWidth = 36;
    private int tileHeight = 18;
    private SpriteBatch batch;
    private Texture img;

    public SimpleView() {
    }

    @Override
    public void setTileset(Texture img) {
        this.img = img;
    }

    @Override
    public void showSnapshot() {
        batch.begin();
        MapSnapshot snapshot = model.prepareSnapshot(0);
        for (int x = 0; x < snapshot.getxSize();
             x++) {
            for (int y = 0; y < snapshot.getySize();
                 y++) {
                Position camera = snapshot.getCamera();
                Position onFramePos = centerPosition(transformPosition(new Position(x - camera.getX(), y - camera.getY(), 0)));
                drawTile(onFramePos, 0);
            }
        }
        batch.end();
    }

    public GameModel getModel() {
        return model;
    }

    public void setModel(GameModel model) {
        this.model = model;
    }

    private void drawTile(Position onFramePos, int id) {
        batch.draw(img, onFramePos.getX(), onFramePos.getY(), tileWidth, tileHeight);
    }

    private Position transformPosition(Position relativePos) {
        int xOffset = (relativePos.getX() + relativePos.getY()) * tileWidth / 2;
        int yOffset = (relativePos.getX() - relativePos.getY()) * tileHeight / 2;
        return new Position(xOffset, yOffset, 0);
    }

    private Position centerPosition(Position pos) {
        return new Position(pos.getX() + (windowWidth /2), pos.getY() + (windowHeight/2), pos.getZ());
    }

    @Override
    public void setWidth(int width) {
        windowWidth = width;
        System.out.println(windowWidth);
    }

    @Override
    public void setHeight(int height) {
        windowHeight = height;
        System.out.println(windowHeight);
    }

    @Override
    public void freeResources() {
        batch.dispose();
        img.dispose();
    }

    @Override
    public void setSpriteBatch(SpriteBatch batch) {
        this.batch = batch;
    }
}