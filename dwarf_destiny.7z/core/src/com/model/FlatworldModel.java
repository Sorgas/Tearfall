package com.model;

import com.model.generator.LocalMapGenerator;
import com.model.localmap.LocalMap;
import com.model.localmap.MapSnapshot;
import com.model.localmap.Position;
import com.model.localmap.MapCell;

/**
 * mock model class
 */
public class FlatworldModel implements GameModel{
	private LocalMap localMap;
	private LocalMapGenerator localMapGenerator;
	private Position camera;

	/**
	 * model constructor. creates flat local with fixed size
	 */
	public FlatworldModel() {
		this.localMapGenerator = new LocalMapGenerator();
		localMap = localMapGenerator.createFlatMap(20,20,1);
		this.camera = new Position(10, 10, 0);
	}
	
	@Override
	public MapSnapshot prepareSnapshot(int zLevel) {
		MapSnapshot snapshot = new MapSnapshot();
		MapCell[][] level = localMap.getLevel(zLevel);
		snapshot.setzLevel(level);
		snapshot.setCamera(camera);
		snapshot.setxSize(localMap.getxSize());
		snapshot.setySize(localMap.getySize());
		return snapshot;
	}

	@Override
	public void makeTurn() {
		
	}
}
