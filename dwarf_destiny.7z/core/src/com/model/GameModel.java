package com.model;

import com.model.localmap.MapSnapshot;

public interface GameModel {
	/**
	 * creates Snapshot object of model !COPING! given z-level
	 * @param zLevel
	 * @return Snapshot
	 */
	public MapSnapshot prepareSnapshot(int zLevel);
	
	public void makeTurn();
}
