package com.model.objects;

public interface Furniture {

}
