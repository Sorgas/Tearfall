package com.model.objects;

public interface Creature {

}
