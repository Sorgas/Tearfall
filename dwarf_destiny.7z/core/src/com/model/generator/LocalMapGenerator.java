package com.model.generator;

import com.model.localmap.LocalMap;
import com.model.localmap.Position;
import com.model.localmap.MapCell;

/**
 * factory class for creating LocalMap objects
 */
public class LocalMapGenerator {

	/**
	 * factory method for flat 1 zlevel maps
	 *
	 * @param xSize
	 * @param ySize
	 * @param zSize
	 * @return complete flat LocalMap
	 */
	public LocalMap createFlatMap(int xSize, int ySize, int zSize) {
		LocalMap map = new LocalMap(xSize, ySize, zSize);
		generateFlat(map);
		return map;
	}

	/**
	 * creates floor cells in one zlevel of map
	 * @param map
	 */
	private void generateFlat(LocalMap map) {
		for (int x = 0; x < map.getxSize(); x++) {
			for (int y = 0; y < map.getxSize(); y++) {
				Position position = new Position(x, y, 0);
				MapCell cell = new MapCell(position, 1, true, false);
				map.setCell(cell);
			}
		}
	}
}
