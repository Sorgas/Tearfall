package com.model.localmap;

/**
 * represents state of LocalMap for rendering purposes
 */
public class MapSnapshot {
	private MapCell[][] zLevel;
	private int xSize; 
	private int ySize;
	private Position camera;
	
	public MapCell[][] getzLevel() {
		return zLevel;
	}

	public void setzLevel(MapCell[][] zLevel) {
		this.zLevel = zLevel;
	}

	public int getxSize() {
		return xSize;
	}

	public void setxSize(int xSize) {
		this.xSize = xSize;
	}

	public int getySize() {
		return ySize;
	}

	public void setySize(int ySize) {
		this.ySize = ySize;
	}

	/**
	 * camera is Position object used to centering picture in screen
	 * @return camera
	 */
	public Position getCamera() {
		return camera;
	}

	/**
	 * camera is Position object used to centering picture in screeт
	 * @param camera camera
	 */
	public void setCamera(Position camera) {
		this.camera = camera;
	}
}