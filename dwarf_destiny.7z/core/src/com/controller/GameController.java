package com.controller;

public interface GameController {

}
